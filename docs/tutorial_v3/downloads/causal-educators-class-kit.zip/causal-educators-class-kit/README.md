# Causal educators' class kit

A 60-90 minute lesson on missing counterfactuals, survival effects over time,
causal survival forests and CAST. All records and numerical examples are synthetic.

## Open or edit

- `study-guide.pdf`: lesson plan, vocabulary, equations, exercises and answer notes.
- `slides.pdf`: draft teaching deck.
- `study-guide.tex` and `slides.tex`: editable LaTeX sources. Upload either to a
  blank Overleaf project, or run `pdflatex study-guide.tex` and `pdflatex slides.tex`
  twice locally. Standard LaTeX packages are required; no private fonts or artwork.
- `class-lab.R`: analyze the included 600-person cohort.
- `cast-exercise.R`: generate another cohort and vary the study settings.
- `R/`: Igor Shuryak's unchanged simulation and CAST implementation, bundled with
  its MIT license. `provenance.json` records the version and file hashes.

## Run the supplied dataset

Unzip the kit. Open R or RStudio with the extracted kit folder as the working
directory, then run:

```r
install.packages(c("survival", "grf")) # once, if these packages are absent
source("class-lab.R")
result <- analyze_demo()
result$results
```

The run uses five horizons and 300 untuned trees to keep the class exercise
manageable. It writes results and a figure to a new folder under `results/`.
Installed R packages are needed; the lab itself makes no network requests.
For more trees, use `analyze_demo(num_trees = 2000)`.

### Why an interval can miss the answer key

Run as above, the causal survival forest (CSF) 95% intervals exclude
`data/answer-key.csv` at several horizons (36, 60 and 108 months on the
supplied cohort, with R 4.5.1 and grf 2.5.0). This is not an installation problem. It is a finite-sample lesson, and
it is measured rather than guessed.

The lab estimates the propensity, each person's probability of treatment given
the measured covariates, with a regression forest, as the website pipeline does.
With only 600 people the forest's estimates are pulled toward the average
treatment rate, so part of the measured selection is left unadjusted. Over 300
freshly simulated 600-person cohorts of the same design, the CSF point estimate
was biased upward by about one standard error after 12 months, and the 95%
intervals contained the answer key only 75-86% of the time, depending on the
horizon. Tuning the propensity forest or using 2,000 trees did not change this.
The standard errors themselves were accurate.

Try the lab with a logistic-regression propensity instead:

```r
logistic <- analyze_demo(propensity = "logistic")
logistic$results
```

With it, the same 600-person cohorts gave unbiased CSF estimates and 94-97%
interval coverage, and on the supplied cohort every CSF interval contains the
answer key. Do not conclude that logistic regression is generally better: in
this simulator the true propensity really is a main-effects logistic model, so
it is correctly specified here by construction. In real data neither model is
known to be right, which is why overlap and sensitivity checks matter.

### Optional Super Learner propensity

The forest remains the default. The optional ensemble combines main-effects
logistic regression (SL.glm), lasso logistic regression (SL.glmnet) and a random
forest (SL.ranger).

```r
install.packages(c("SuperLearner", "glmnet", "ranger"))
ensemble <- analyze_demo(propensity = "superlearner")
ensemble$results
```

Five stratified outer folds predict each person's treatment probability without
using that person in fitting or ensemble weighting. Five inner folds learn
nonnegative ensemble weights with binomial log-loss. Only measured baseline
covariates and treatment assignment enter these fits. Probabilities are clipped
to [0.01, 0.99], as for the other options. Candidate failures stop the run rather
than silently dropping a learner. The run record includes the seed and settings.

### Understanding overlap warnings

Some runs, including the Super Learner option, can warn that estimated treatment
probabilities are close to zero or one. People with those covariates have few
comparable observations in the other treatment group, so their contribution to
an adjusted effect can be unstable. This is a diagnostic about support for the
comparison, not an installation failure or proof that the ensemble is wrong.

Inspect the probabilities used by the lab, including their distribution in
each treatment group:

```r
range(ensemble$propensity)
tapply(ensemble$propensity, ensemble$cohort$W, summary)
```

The [0.01, 0.99] clipping limits extreme weights; it does not create missing
comparisons or establish adequate overlap. A learner that pulls probabilities
toward the middle may emit fewer warnings without improving adjustment. Keep
the warnings visible and discuss them alongside the known truth and interval
coverage. Do not automatically trim observations or switch the target population
to silence a warning: that would change the estimand and require a matching
answer key.

For a fixed seed and the same R/package environment, the test suite checks that
repeated Super Learner runs return identical propensity vectors, even after
unrelated random draws. The run record captures package versions; identical
results across different versions or platforms are not promised.

### Comparing the propensity options

The logistic option uses in-sample fitted probabilities; the forest uses
out-of-bag predictions. This exercise therefore varies both the learner and
how predictions are obtained. The earlier coverage study did not include
Super Learner. A [new 300-cohort comparison](https://github.com/ishuryak/cast_demo_website/blob/main/tutorial/validation/2026-10-19-propensity/README.md)
on October 19 reports bias and interval coverage for all three options:
CSF coverage across the five horizons was 74.7–86.3% with forest, 94.3–96.7%
with logistic, and 93.7–96.0% with Super Learner. CSF bias ranged from +1.58 to
+5.30 percentage points, −0.19 to +0.03, and +0.12 to +0.50, respectively.
These are results for the correctly specified logistic treatment generator,
not general superiority claims. Super Learner does not fix hidden confounding,
missing overlap or CAST curve misspecification; forest remains the default.

The CAST band is a separate matter: uncertainty around a fitted quadratic does
not guarantee coverage of the underlying effect curve. The band does not fully
account for approximation or model-selection uncertainty. At 36 months in the
October 19 comparison, the two coverage measures were:

| Propensity option | CSF interval coverage | CAST pointwise band coverage |
| --- | ---: | ---: |
| Forest | 76.0% | 84.3% |
| Logistic | 94.3% | 44.3% |
| Super Learner | 93.7% | 47.7% |

All intervals are nominally 95%. Coverage is the fraction of the 300 intervals
containing the replicate-specific true average effect, not the fraction of
people benefiting. The reversal pattern is not quadratic; the logistic CAST
band also covered only 79.7% at 84 months. Good CSF coverage does not guarantee
good CAST coverage. The walkthrough shows these measures side by side.

The October 19 study used glmnet 5.1. A separate
[matched version audit](https://github.com/ishuryak/cast_demo_website/blob/main/tutorial/validation/2026-10-24-glmnet/README.md)
found identical propensity vectors and CSF/CAST estimates and interval endpoints
with glmnet 4.1-10 and 5.1 on 20 paired cohorts under a fixed R 4.5.2 Windows
environment. This checks the lab's binomial propensity path; it does not validate
Cox models or reproduce the original macOS environment. Keep the original run's
version label and the pilot's 4.1-10 pin.

The earlier study is `tutorial/scripts/class-lab-coverage-study.R`. The October 19
comparison uses `tutorial/scripts/class-lab-propensity-study.R`, with replicate
results, summaries and Monte Carlo standard errors linked above. It is a new
run; the original October 1 comparison files were not recovered.

To generate a different study using the bundled source:

```r
source("cast-exercise.R")
another <- run_cast_exercise(seed = 20260906, source_dir = "R")
hidden <- run_cast_exercise(hidden_confounding = 1.5, source_dir = "R")
```

These functions preserve earlier output folders. Generated cohorts can include
the generator's `u_hidden` column for teaching; it never enters the fitted models.

## Which data are which?

`data/demo-cohort.csv` contains **600 new synthetic people**, generated with seed
20260905, the reversal pattern, measured-confounding strength 1 and hidden-confounding
strength 0. It is ready for analysis with `class-lab.R`.

| Column | Meaning |
| --- | --- |
| `age` | Baseline age in years, drawn from a normal distribution |
| `stage` | Simulated ordinal disease stage, 1-4 |
| `ps` | Baseline performance score, 40-100; larger is better |
| `comorb` | Simulated comorbidity count, 0-4 |
| `smoke` | Simulated ever-smoking indicator, 0/1 |
| `sex` | Generator's synthetic binary coding, 0=female and 1=male |
| `ethnicity` | Arbitrary simulated labels A/B/C, with no real-world group meaning |
| `W` | Baseline treatment assignment, 1=treatment and 0=control |
| `Y` | Observed follow-up time in months: the earlier of event and censoring |
| `D` | 1=observed death at Y; 0=censored at Y |

Sex and ethnicity affect nothing in this particular generator. These design
choices are teaching devices, not claims about real patients or populations.
Censoring before a horizon does not mean that the person died by that horizon.

`data/answer-key.csv` contains `month` and `truth`: the average difference between
the two conditional survival probabilities for those **same 600 profiles**. It
does not contain paired individual outcomes and is never supplied to a forest.

`data/frozen-horizons.csv` contains the **website's separate 2,000-person scenarios**:
24 scenarios by five horizons = 120 rows. `scenario` identifies the effect pattern
and confounding settings; `month` is follow-up time. `csf`, `cast`, `truth` and
`unadjusted` are probability differences. Multiply by 100 for percentage points.
The `_low` and `_high` columns are 95% interval/band limits. The CAST limits are
pointwise, not simultaneous across time; they do not include all uncertainty
from method selection or quadratic misspecification.

**The 600-person lab should not reproduce the frozen website's exact decimals.**
The CSVs can be inspected with base R or a spreadsheet even without grf.

## Sources and reuse

- [Igor Shuryak's CAST repository: code, detailed methods and audits](https://github.com/ishuryak/cast_demo_website)
- [Bundled source revision](https://github.com/ishuryak/cast_demo_website/tree/43a00101100801eb6c048800d24788455fac0f8b)

The guide and slides include scientific references. Keep the supplied MIT notice
with copies of Igor's code. Edit the draft teaching materials for your class.

## AI assistance

Parts of the text, code review and visual checks were prepared with the help of AI assistants (OpenAI Codex, Anthropic Claude and Google Gemini). The authors are responsible for the scientific content.
